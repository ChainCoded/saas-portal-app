#!/bin/bash
set -e

yum update -y
yum install -y httpd curl

sed -i 's/^Listen 80/Listen 8080/' /etc/httpd/conf/httpd.conf
sed -i 's/<VirtualHost \*:80>/<VirtualHost *:8080>/' /etc/httpd/conf/httpd.conf || true

systemctl enable httpd